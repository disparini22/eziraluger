<?php

$config = array(
  	'db_host' => 'localhost',
    'db_user' => 'bancopadrao090909',
    'db_pass' => 'KDvVzf3rzyVAuvvu1PHZ',
    'db_name' => 'bancopadrao090909'
);

?>
